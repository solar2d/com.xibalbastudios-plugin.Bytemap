local metadata =
{
	plugin =
	{
		format = 'sharedLibrary',
		staticLibs = { 'plugin.Bytemap', },
		frameworks = {},
		frameworksOptional = {},
	},
}

return metadata
