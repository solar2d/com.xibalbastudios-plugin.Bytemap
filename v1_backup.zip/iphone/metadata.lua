local metadata =
{
	plugin =
	{
		format = 'staticLibrary',
		staticLibs = { 'plugin_Bytemap' },
		frameworks = {},
		frameworksOptional = {},
	},
}

return metadata
